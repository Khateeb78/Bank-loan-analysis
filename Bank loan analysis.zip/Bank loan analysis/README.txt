BANK LOAN DASHBOARD - HOW TO RUN
================================
Folder contents:
  index.html            page structure
  style.css             styling
  script.js             loads CSV, calculates KPIs, filters, charts
  data/bank_loan_data.csv   38,576 loan records

Option A (easiest): double-click index.html, then use the "Data file" box
  in the left panel and choose data/bank_loan_data.csv.
  (Browsers block auto-loading files opened directly, so this step is needed.)

Option B (auto-loads): open a terminal in this folder and run
  python -m http.server 8000
  then open http://localhost:8000 in your browser.

Option C: VS Code > install "Live Server" > right click index.html > Open with Live Server.
