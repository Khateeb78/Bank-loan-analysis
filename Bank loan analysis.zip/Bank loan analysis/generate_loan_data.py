"""Generate a synthetic bank loan dataset (38,576 rows) calibrated to the dashboard screenshot.
Run: python generate_loan_data.py  ->  bank_loan_data.csv
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)

# status: (rows, total funded, total received, avg int rate %, avg dti %)
STATUS = {
    "Fully Paid":  (32145, 351_358_350, 411_586_256, 11.64, 13.17),
    "Current":     (1098,   18_866_500,  24_199_914, 15.10, 14.72),
    "Charged Off": (5333,   65_532_225,  37_284_763, 13.88, 14.00),
}
PURPOSES = ["Debt consolidation", "Credit card", "Home improvement", "Major purchase",
            "Small business", "Car", "Medical", "Other"]
PURPOSE_P = [0.47, 0.13, 0.08, 0.06, 0.05, 0.04, 0.02, 0.15]
STATES = ["CA", "NY", "TX", "FL", "IL", "NJ", "PA", "VA", "GA", "OH"]
STATE_P = [0.18, 0.10, 0.07, 0.07, 0.04, 0.04, 0.04, 0.03, 0.03, 0.40]
GRADES = ["A", "B", "C", "D", "E", "F", "G"]
EMP = ["< 1 year", "1 year", "2 years", "3 years", "5 years", "7 years", "10+ years"]


def scale_to_total(x, total):
    x = np.round(x / x.sum() * total / 25) * 25  # loan amounts in $25 steps
    x[0] += total - x.sum()
    return x


frames = []
for status, (n, funded, received, rate, dti) in STATUS.items():
    # riskier status -> worse grades
    gp = {"Fully Paid": [.27, .32, .22, .11, .05, .02, .01],
          "Current":    [.10, .25, .30, .20, .10, .04, .01],
          "Charged Off":[.08, .20, .28, .22, .13, .06, .03]}[status]
    df = pd.DataFrame({
        "loan_status": status,
        "loan_amount": scale_to_total(rng.gamma(2.5, 4000, n).clip(500, 35000), funded),
        "int_rate": np.clip(rng.normal(rate, 3.2, n), 5.4, 24.0) / 100,
        "dti": np.clip(rng.normal(dti, 6.5, n), 0, 30) / 100,
        "grade": rng.choice(GRADES, n, p=gp),
    })
    df["total_payment"] = df["loan_amount"] * 0  # fill below to hit exact total
    w = rng.uniform(0.6, 1.4, n) * df["loan_amount"]
    df["total_payment"] = np.round(w / w.sum() * received)
    df.loc[df.index[0], "total_payment"] += received - df["total_payment"].sum()
    frames.append(df)

loans = pd.concat(frames, ignore_index=True).sample(frac=1, random_state=1).reset_index(drop=True)
n = len(loans)
loans.insert(0, "id", np.arange(1_000_001, 1_000_001 + n))
loans["issue_date"] = pd.to_datetime("2021-01-01") + pd.to_timedelta(
    rng.choice(365, n, p=np.linspace(0.6, 1.4, 365) / np.linspace(0.6, 1.4, 365).sum()), unit="D")
loans["purpose"] = rng.choice(PURPOSES, n, p=PURPOSE_P)
loans["addr_state"] = rng.choice(STATES, n, p=STATE_P)
loans["emp_length"] = rng.choice(EMP, n)
loans["term"] = rng.choice(["36 months", "60 months"], n, p=[0.73, 0.27])
loans["annual_income"] = np.round(rng.lognormal(11.1, 0.5, n), -2)
loans["issue_date"] = loans["issue_date"].dt.strftime("%Y-%m-%d")

cols = ["id", "issue_date", "loan_status", "loan_amount", "total_payment", "int_rate", "dti",
        "purpose", "grade", "addr_state", "emp_length", "term", "annual_income"]
loans[cols].to_csv("bank_loan_data.csv", index=False)

print(loans.groupby("loan_status").agg(apps=("id", "count"), funded=("loan_amount", "sum"),
      received=("total_payment", "sum"), rate=("int_rate", "mean"), dti=("dti", "mean")))
print("Rows:", n)
