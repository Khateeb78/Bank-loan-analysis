/* Bank Loan Dashboard - plain JavaScript, no libraries */
let DATA = [];

const $ = s => document.querySelector(s);
const fmtMoney = v => v >= 1e6 ? '$' + (v / 1e6).toFixed(1) + 'M'
                    : v >= 1e3 ? '$' + (v / 1e3).toFixed(1) + 'K' : '$' + v.toFixed(0);
const fmtCount = v => v >= 1e3 ? (v / 1e3).toFixed(1) + 'K' : String(v);
const pct = (v, d = 2) => (v * 100).toFixed(d) + '%';
const sum = (a, k) => a.reduce((s, r) => s + r[k], 0);
const avg = (a, k) => a.length ? sum(a, k) / a.length : 0;
const isGood = r => r.loan_status !== 'Charged Off';

/* ---------- Load CSV ---------- */
function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  const head = lines[0].split(',');
  const num = ['id', 'loan_amount', 'total_payment', 'int_rate', 'dti', 'annual_income'];
  return lines.slice(1).map(l => {
    const c = l.split(','), o = {};
    head.forEach((h, i) => o[h] = num.includes(h) ? parseFloat(c[i]) : c[i]);
    o.month = o.issue_date.slice(0, 7);
    return o;
  });
}
function init(text, source) {
  DATA = parseCSV(text);
  $('#status').textContent = `${DATA.length.toLocaleString()} rows loaded (${source})`;
  fillFilter('#fPurpose', 'purpose'); fillFilter('#fGrade', 'grade'); fillFilter('#fState', 'addr_state');
  render();
}
function fillFilter(sel, key) {
  const el = $(sel);
  el.innerHTML = '<option value="All">All</option>';
  [...new Set(DATA.map(r => r[key]))].sort().forEach(v => el.add(new Option(v, v)));
}
fetch('data/bank_loan_data.csv')
  .then(r => { if (!r.ok) throw 0; return r.text(); })
  .then(t => init(t, 'data/bank_loan_data.csv'))
  .catch(() => $('#status').textContent = 'Could not auto-load. Use a local server or choose the CSV below.');
$('#csvFile').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  const rd = new FileReader(); rd.onload = () => init(rd.result, f.name); rd.readAsText(f);
};

/* ---------- Filters & navigation ---------- */
['#fPurpose', '#fGrade', '#fState'].forEach(s => $(s).onchange = render);
document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
  document.querySelectorAll('nav button').forEach(x => x.classList.remove('on')); b.classList.add('on');
  document.querySelectorAll('.page').forEach(p => p.classList.remove('on'));
  $('#' + b.dataset.page).classList.add('on');
  $('#title').textContent = b.textContent.toUpperCase();
});
function filtered() {
  const p = $('#fPurpose').value, g = $('#fGrade').value, s = $('#fState').value;
  return DATA.filter(r => (p === 'All' || r.purpose === p) && (g === 'All' || r.grade === g) &&
                          (s === 'All' || r.addr_state === s));
}

/* ---------- Render ---------- */
function render() {
  if (!DATA.length) return;
  const rows = filtered();
  summary(rows); overview(rows); details(rows);
}

function monthStats(rows, month, fn) { return fn(rows.filter(r => r.month === month)); }

function summary(rows) {
  const months = [...new Set(rows.map(r => r.month))].sort();
  const cur = months[months.length - 1], prev = months[months.length - 2];
  const mom = (fn) => {
    if (!cur || !prev) return 0;
    const a = monthStats(rows, cur, fn), b = monthStats(rows, prev, fn);
    return b ? (a - b) / b : 0;
  };
  const kpis = [
    ['Total Loan Applications', fmtCount(rows.length), fmtCount(monthStats(rows, cur, r => r.length)), mom(r => r.length), 'hl'],
    ['Total Funded Amount', fmtMoney(sum(rows, 'loan_amount')), fmtMoney(monthStats(rows, cur, r => sum(r, 'loan_amount'))), mom(r => sum(r, 'loan_amount'))],
    ['Total Amount Received', fmtMoney(sum(rows, 'total_payment')), fmtMoney(monthStats(rows, cur, r => sum(r, 'total_payment'))), mom(r => sum(r, 'total_payment'))],
    ['Avg Interest Rate', pct(avg(rows, 'int_rate')), pct(monthStats(rows, cur, r => avg(r, 'int_rate')), 1), mom(r => avg(r, 'int_rate'))],
    ['Avg DTI', pct(avg(rows, 'dti')), pct(monthStats(rows, cur, r => avg(r, 'dti')), 1), mom(r => avg(r, 'dti'))],
  ];
  $('#kpis').innerHTML = kpis.map(k => `<div class="kpi ${k[4] || ''}"><small>${k[0]}</small><b>${k[1]}</b>
    <div class="sub"><div>MTD<b>${k[2]}</b></div><div>MoM<b class="mom">${pct(k[3], 1)}</b></div></div></div>`).join('');

  const good = rows.filter(isGood), bad = rows.filter(r => !isGood(r));
  const gp = rows.length ? good.length / rows.length : 0;
  $('#goodPct').textContent = pct(gp, 1); $('#badPct').textContent = pct(1 - gp, 1);
  $('#goodDonut').style.background = `conic-gradient(var(--gold) 0 ${gp * 100}%, var(--grey) 0)`;
  $('#badDonut').style.background = `conic-gradient(var(--magenta) 0 ${(1 - gp) * 100}%, var(--grey) 0)`;
  const stats = (a, w) => `<p>${w} Loan Applications<b>${fmtCount(a.length)}</b></p>
    <p>${w} Loan Funded Amount<b>${fmtMoney(sum(a, 'loan_amount'))}</b></p>
    <p>${w} Loan Total Received<b>${fmtMoney(sum(a, 'total_payment'))}</b></p>`;
  $('#goodStats').innerHTML = stats(good, 'Good'); $('#badStats').innerHTML = stats(bad, 'Bad');

  const usd = v => '$' + Math.round(v).toLocaleString('en-US');
  const line = (label, a, cls = '') => `<tr class="${cls}"><td>${label}</td><td>${a.length.toLocaleString()}</td>
    <td>${usd(sum(a, 'loan_amount'))}</td><td>${usd(sum(a, 'total_payment'))}</td>
    <td>${usd(monthStats(a, cur, r => sum(r, 'loan_amount')))}</td><td>${usd(monthStats(a, cur, r => sum(r, 'total_payment')))}</td>
    <td>${pct(avg(a, 'int_rate'))}</td><td>${pct(avg(a, 'dti'))}</td></tr>`;
  $('#statusTable').innerHTML = `<tr><th>Loan Status</th><th>Total Loan Applications</th><th>Total Funded Amount</th>
    <th>Total Amount Received</th><th>MTD Funded Amount</th><th>MTD Amount Received</th><th>Avg Interest Rate</th><th>Avg DTI</th></tr>` +
    ['Fully Paid', 'Current', 'Charged Off'].map(s => line(s, rows.filter(r => r.loan_status === s))).join('') +
    line('Grand Total', rows, 'total');
}

/* ---------- Simple SVG bar charts ---------- */
function bars(sel, labels, series, colors, fmt) {
  const svg = $(sel), [, , W, H] = svg.getAttribute('viewBox').split(' ').map(Number);
  const mx = Math.max(...series.flat(), 1e-9) * 1.15, n = labels.length, gw = (W - 50) / n, bw = gw / (series.length + 1);
  let h = '';
  labels.forEach((l, i) => {
    series.forEach((s, j) => {
      const bh = s[i] / mx * (H - 45), x = 40 + i * gw + j * bw + bw / 2, y = H - 25 - bh;
      h += `<rect x="${x}" y="${y}" width="${bw * .9}" height="${bh}" fill="${colors[j]}" rx="2"/>
            <text x="${x + bw * .45}" y="${y - 4}" fill="#c9d6ff" font-size="10" text-anchor="middle">${fmt(s[i])}</text>`;
    });
    h += `<text x="${40 + i * gw + gw / 2}" y="${H - 8}" fill="#c9d6ff" font-size="11" text-anchor="middle">${l}</text>`;
  });
  svg.innerHTML = h;
}
const group = (rows, key) => { const m = {}; rows.forEach(r => (m[r[key]] = m[r[key]] || []).push(r)); return m; };
const badRate = a => a.length ? a.filter(r => !isGood(r)).length / a.length : 0;
const M = v => (v / 1e6).toFixed(1);

function overview(rows) {
  const byM = group(rows, 'month'), ms = Object.keys(byM).sort();
  const names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  bars('#cTrend', ms.map(m => names[+m.slice(5) - 1]),
    [ms.map(m => sum(byM[m], 'loan_amount') / 1e6), ms.map(m => sum(byM[m], 'total_payment') / 1e6)],
    ['#3aa0ff', '#f1c40f'], v => v.toFixed(1));

  const top = (key, k) => Object.entries(group(rows, key)).map(([n, a]) => [n, sum(a, 'loan_amount')])
    .sort((a, b) => b[1] - a[1]).slice(0, k);
  const s = top('addr_state', 10), p = top('purpose', 8);
  bars('#cState', s.map(x => x[0]), [s.map(x => x[1] / 1e6)], ['#3aa0ff'], v => v.toFixed(1));
  bars('#cPurpose', p.map(x => x[0].split(' ')[0]), [p.map(x => x[1] / 1e6)], ['#3aa0ff'], v => v.toFixed(1));

  const gr = group(rows, 'grade'), gk = Object.keys(gr).sort();
  bars('#cGrade', gk, [gk.map(k => badRate(gr[k]) * 100)], ['#e91eff'], v => v.toFixed(1) + '%');

  const band = r => r.dti < .10 ? '0-10%' : r.dti < .20 ? '10-20%' : r.dti < .30 ? '20-30%' : '30%+';
  const db = {}; rows.forEach(r => (db[band(r)] = db[band(r)] || []).push(r));
  const dk = ['0-10%', '10-20%', '20-30%', '30%+'].filter(k => db[k]);
  bars('#cDti', dk, [dk.map(k => badRate(db[k]) * 100)], ['#e91eff'], v => v.toFixed(1) + '%');
}

function details(rows) {
  const cols = ['id', 'issue_date', 'loan_status', 'loan_amount', 'total_payment', 'int_rate', 'dti', 'purpose', 'grade', 'addr_state', 'term'];
  $('#detailTable').innerHTML = '<tr>' + cols.map(c => `<th>${c}</th>`).join('') + '</tr>' +
    rows.slice(0, 200).map(r => '<tr>' + cols.map(c => `<td>${
      c === 'int_rate' || c === 'dti' ? pct(r[c]) : c.includes('amount') || c === 'total_payment' ? '$' + r[c].toLocaleString() : r[c]}</td>`).join('') + '</tr>').join('');
}
